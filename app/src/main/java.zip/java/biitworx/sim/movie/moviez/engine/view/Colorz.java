package biitworx.sim.movie.moviez.engine.view;

/**
 * Created by marcel.weissgerber on 16.08.2016.
 */
public class Colorz {


}
