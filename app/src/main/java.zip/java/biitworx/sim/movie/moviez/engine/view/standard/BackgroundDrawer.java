package biitworx.sim.movie.moviez.engine.view.standard;

import android.graphics.Paint;
import android.graphics.Rect;

import biitworx.sim.movie.moviez.R;
import biitworx.sim.movie.moviez.engine.view.Drawer;
import biitworx.sim.movie.moviez.engine.view.Static;
import biitworx.sim.movie.moviez.engine.view.stripe.MovieStripe;
import biitworx.sim.movie.moviez.engine.view.stripe.MovieStripeMenu;
import biitworx.sim.movie.moviez.global.B;
import biitworx.sim.movie.moviez.global.BitmapDrawer;
import biitworx.sim.movie.moviez.global.MenuStripesFactory;

/**
 * Created by marce_000 on 15.08.2016.
 */
public class BackgroundDrawer extends Drawer {

    private MovieStripeMenu menu = new MovieStripeMenu();

    @Override
    protected void onDraw() {
        if (!canDraw()) return;


        BitmapDrawer.drawImage(B.get(R.drawable.back), canvas, bounds, null, false);

        Paint back = new Paint();
        back.setStyle(Paint.Style.FILL);
        back.setColor(Static.getBack());
        int top = 18;

        canvas.drawRect(new Rect(bounds.left, bounds.top, bounds.right, bounds.top + top), back);
        canvas.drawRect(new Rect(bounds.left, (int) (bounds.bottom - top * 1.3), bounds.right, bounds.bottom), back);
        int max = (bounds.height() - top * 2) / 10;
        //canvas.drawRect(new Rect(bounds.left, bounds.top+max+top, bounds.right, (bounds.top+max+top + top/2)-top/10), back);

        if (menu.isCreated()) {
            int width = (int) (bounds.width() / 6);


            Rect rc = new Rect(bounds.left+width,bounds.top+top,bounds.right-width,bounds.top+max+top);

            int w2 = rc.width()/3;
            menu.add( new MovieStripe(new Rect(rc.left,rc.top,rc.left+w2,rc.bottom)).loop(true));
            menu.add( new MovieStripe(new Rect(rc.left+w2,rc.top,rc.left+w2*2,rc.bottom)).loop(true));
            menu.add( new MovieStripe(new Rect(rc.left+w2*2,rc.top,rc.left+w2*3,rc.bottom)).loop(true));

            for (int x = 0; x < 10; x++) {
                menu.add(MenuStripesFactory.getMenuStripe(x,new Rect(0, top, width, top + max)));
                menu.add(MenuStripesFactory.getMenuStripe(x+10,new Rect(bounds.right - width, top, bounds.right, top + max)));

                top += max;
            }


        }

        menu.draw(canvas);

    }

    @Override
    public void checkHit(int x, int y) {
        menu.checkHit(x, y);
    }


}
