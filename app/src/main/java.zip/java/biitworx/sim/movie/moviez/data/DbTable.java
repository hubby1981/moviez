package biitworx.sim.movie.moviez.data;

/**
 * Created by marcel.weissgerber on 25.05.2016.
 */
public @interface DbTable{
    String name();
}
