package biitworx.sim.movie.moviez;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import biitworx.sim.movie.moviez.data.helper.DbHelper;
import biitworx.sim.movie.moviez.engine.view.Background;

public class Game extends AppCompatActivity {


    public static Resources res;
    public static DbHelper DATA;
    private Background background;
    public static Runnable update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        res = getResources();
        DATA = new DbHelper(this);


        update = new Runnable() {
            @Override
            public void run() {
                background = (Background) findViewById(R.id.gameback);
                background.invalidate();
            }
        };

        runOnUiThread(update);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (event.getAction() == MotionEvent.ACTION_UP) {
            background = (Background) findViewById(R.id.gameback);
            background.checkHit((int) event.getX(), (int) event.getY());
        }
        update.run();

        return true;
    }
}
