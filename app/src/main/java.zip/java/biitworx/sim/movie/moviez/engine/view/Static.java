package biitworx.sim.movie.moviez.engine.view;

import android.graphics.Color;

/**
 * Created by marcel.weissgerber on 16.08.2016.
 */
public class Static {
    public static int getBack(){
        return Color.argb(255, 45, 55, 65);
    }
}
